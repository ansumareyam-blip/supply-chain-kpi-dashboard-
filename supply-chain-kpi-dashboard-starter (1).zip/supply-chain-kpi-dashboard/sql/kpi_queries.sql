-- Supply Chain KPI Dashboard: example SQL queries
-- Assumes sample_logistics_data.csv has been imported into a table named logistics_orders.
-- SQL dialect: broadly compatible with PostgreSQL; adjust date functions for other systems.

-- 1. On-time delivery rate by region
SELECT
    region,
    ROUND(100.0 * AVG(on_time_flag), 1) AS on_time_delivery_pct,
    COUNT(*) AS shipment_count
FROM logistics_orders
GROUP BY region
ORDER BY on_time_delivery_pct DESC;

-- 2. Average shipping cost by product category
SELECT
    product_category,
    ROUND(AVG(shipping_cost_eur), 2) AS avg_shipping_cost_eur,
    COUNT(*) AS shipment_count
FROM logistics_orders
GROUP BY product_category
ORDER BY avg_shipping_cost_eur DESC;

-- 3. Inventory units and inventory value by region
SELECT
    region,
    SUM(inventory_units) AS inventory_units,
    ROUND(SUM(inventory_value_eur), 2) AS inventory_value_eur
FROM logistics_orders
GROUP BY region
ORDER BY inventory_value_eur DESC;

-- 4. Late deliveries to investigate
SELECT
    order_id, region, product_category, promised_delivery_date,
    actual_delivery_date, delivery_days, shipping_cost_eur
FROM logistics_orders
WHERE on_time_flag = 0
ORDER BY actual_delivery_date DESC;

-- 5. Monthly shipment count (PostgreSQL)
SELECT
    DATE_TRUNC('month', order_date)::date AS order_month,
    COUNT(*) AS shipment_count,
    ROUND(AVG(shipping_cost_eur), 2) AS avg_shipping_cost_eur
FROM logistics_orders
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY order_month;
