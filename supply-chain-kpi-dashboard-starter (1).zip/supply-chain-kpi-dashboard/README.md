# Supply Chain KPI Dashboard (Portfolio Project)

**Tools:** Power BI, Power Query, DAX, SQL, Excel  
**Data:** Synthetic sample logistics data created for portfolio practice. It is not company or customer data.

## Project goal
Create a simple interactive dashboard to monitor delivery reliability, inventory, and shipping costs by region and product category.

## KPIs
- **On-time delivery rate:** share of orders delivered on or before the promised date.
- **Inventory units:** total units represented in the sample records.
- **Inventory value (€):** inventory units multiplied by unit cost.
- **Cost per shipment (€):** average shipping cost per order.
- **Average delivery time (days):** average days from order date to actual delivery date.

## Repository contents
- `data/sample_logistics_data.csv` — synthetic dataset for practice.
- `sql/kpi_queries.sql` — example SQL queries for KPI calculations.
- `docs/power_bi_build_guide.md` — steps to build the report and suggested DAX measures.

## How to use
1. Download or clone this repository.
2. Import `data/sample_logistics_data.csv` into Power BI Desktop.
3. In Power Query, set the three date columns to Date and check numeric data types.
4. Create the DAX measures in the build guide.
5. Add KPI cards, a monthly trend chart, and slicers for region and product category.
6. Publish screenshots of your completed report in this README, or link to a public Power BI report only if you intentionally make it public.

## Suggested dashboard layout
- KPI cards across the top: On-time Delivery %, Inventory Units, Inventory Value, Average Shipping Cost, Average Delivery Days.
- Bar chart: on-time delivery rate by region.
- Line chart: order volume by month.
- Bar chart: shipping cost by product category.
- Slicers: region, product category, order date.

## Portfolio integrity
This repository is a starter project and contains a dataset, SQL examples, and build instructions. Update this README only after you have actually built and tested the Power BI dashboard. Do not claim dashboard development, SQL use, or DAX measures as completed until you can demonstrate them.
