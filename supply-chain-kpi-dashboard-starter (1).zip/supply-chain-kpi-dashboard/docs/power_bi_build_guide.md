# Power BI Build Guide

## 1. Import and check data
Import `data/sample_logistics_data.csv` into Power BI Desktop. Confirm:
- `order_date`, `promised_delivery_date`, `actual_delivery_date` are Date.
- `units_ordered`, `inventory_units`, `on_time_flag`, `delivery_days` are Whole Number.
- `unit_cost_eur`, `shipping_cost_eur`, `inventory_value_eur` are Decimal Number / Fixed Decimal Number.

The CSV includes derived columns for easier learning. To practise Power Query, you can remove `on_time_flag`, `delivery_days`, and `inventory_value_eur` and recreate them.

## 2. Optional Power Query custom columns
- `OnTimeFlag`: `if [actual_delivery_date] <= [promised_delivery_date] then 1 else 0`
- `DeliveryDays`: `Duration.Days([actual_delivery_date] - [order_date])`
- `InventoryValueEUR`: `[inventory_units] * [unit_cost_eur]`

## 3. DAX measures
Assume the imported table is named `logistics_orders`. If Power BI names it differently, replace the table name in each formula.

```DAX
Shipment Count = COUNTROWS(logistics_orders)

On-Time Delivery % =
DIVIDE(
    SUM(logistics_orders[on_time_flag]),
    [Shipment Count],
    0
)

Inventory Units = SUM(logistics_orders[inventory_units])

Inventory Value (€) = SUM(logistics_orders[inventory_value_eur])

Average Shipping Cost (€) = AVERAGE(logistics_orders[shipping_cost_eur])

Average Delivery Days = AVERAGE(logistics_orders[delivery_days])

Late Shipments =
CALCULATE(
    [Shipment Count],
    logistics_orders[on_time_flag] = 0
)
```

Format `On-Time Delivery %` as Percentage with one decimal place; currency measures as Euro.

## 4. Recommended visuals
1. Cards: On-Time Delivery %, Inventory Units, Inventory Value (€), Average Shipping Cost (€), Average Delivery Days.
2. Clustered bar chart: Region on axis, On-Time Delivery % as value.
3. Column chart: Product Category on axis, Average Shipping Cost (€) as value.
4. Line chart: Order Date on axis (use month level), Shipment Count as value.
5. Slicers: Region, Product Category, Order Date.

## 5. Check before publishing
- Test every slicer.
- Verify KPI totals against the CSV and SQL queries.
- Use only synthetic/sample data for public reports.
- Power BI's "Publish to web" can make the report publicly accessible. Never use confidential or personal data.
